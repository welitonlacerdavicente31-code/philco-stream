# Philco Stream — protótipo 0.1.0

Projeto inicial de aplicativo Android para TV com Android 4.4 (API 19), usando Java e Views/XML.

## O que já existe
- Interface escura e simples, em orientação horizontal.
- Controles focáveis para navegação pelo controle remoto.
- Tela inicial de protótipo.
- Campo para inserir URL de manifesto de add-on e validar se retorna JSON com manifesto.
- Requisições HTTP fora da thread principal.

## O que ainda NÃO existe
- Não é ainda um cliente Stremio completo.
- Não lista catálogos nem pesquisa títulos reais.
- Não reproduz streams.
- Não salva add-ons depois de fechar o aplicativo.
- A compatibilidade de cada add-on/stream ainda precisa ser implementada e testada.

## Compilar
Requer JDK 17, Android SDK e Gradle 8.7 compatível com Android Gradle Plugin 8.6.1.
Abra a pasta no Android Studio ou configure um runner de build na nuvem.
Com Gradle instalado: `gradle assembleDebug`

O APK de debug deverá ficar em `app/build/outputs/apk/debug/app-debug.apk`.

## Nota sobre Android 4.4
`minSdk 19` permite instalar em Android 4.4, mas não garante que todo vídeo, codec ou add-on funcione. O player e os protocolos de streams serão escolhidos/implementados numa etapa posterior.
