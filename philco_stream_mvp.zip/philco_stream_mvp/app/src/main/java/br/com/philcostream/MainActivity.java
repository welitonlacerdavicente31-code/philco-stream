package br.com.philcostream;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(16, 19, 25);
    private final int PANEL = Color.rgb(27, 34, 44);
    private final int MUTED = Color.rgb(160, 173, 188);
    private final int ACCENT = Color.rgb(98, 214, 167);
    private LinearLayout root, content;
    private TextView status;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        buildUi();
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(28), dp(20), dp(28), dp(18));
        root.setBackgroundColor(BG);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOrientation(LinearLayout.HORIZONTAL);
        TextView logo = text("PHILCO STREAM", 23, Color.WHITE, true);
        header.addView(logo, new LinearLayout.LayoutParams(0, -2, 1));
        Button add = button("+ Adicionar catálogo");
        add.setOnClickListener(v -> askAddon());
        header.addView(add);
        root.addView(header);

        TextView subtitle = text("Streaming aberto • interface leve para TV", 13, MUTED, false);
        LinearLayout.LayoutParams subP = new LinearLayout.LayoutParams(-1, -2);
        subP.topMargin = dp(4);
        root.addView(subtitle, subP);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(18), 0, dp(12));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        status = text("Versão inicial • Ainda não há add-ons instalados.", 14, MUTED, false);
        LinearLayout.LayoutParams st = new LinearLayout.LayoutParams(-1, -2);
        st.topMargin = dp(8);
        root.addView(status, st);

        setContentView(root);
        showWelcome();
    }

    private void showWelcome() {
        content.removeAllViews();
        content.addView(text("Sua central de filmes e séries", 27, Color.WHITE, true));
        TextView p = text("A base está pronta para TV: foco pelo controle remoto, layout escuro e componentes nativos. Instale um add-on compatível para começar a explorar catálogos.", 16, MUTED, false);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, -2);
        pp.topMargin = dp(8);
        content.addView(p, pp);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(20), 0, dp(12));
        row.addView(tile("CATÁLOGOS", "Adicione um add-on Stremio", "＋", () -> askAddon()),
                new LinearLayout.LayoutParams(0, dp(132), 1));
        row.addView(tile("BUSCA", "Pesquise no catálogo carregado", "⌕", () -> askSearch()),
                new LinearLayout.LayoutParams(0, dp(132), 1));
        row.addView(tile("PROJETO", "Android 4.4 • API 19+", "✓", () -> info()),
                new LinearLayout.LayoutParams(0, dp(132), 1));
        content.addView(row);
        content.addView(text("Próxima etapa: listar títulos reais e abrir streams devolvidos pelo add-on.", 14, MUTED, false));
    }

    private View tile(String title, String desc, String symbol, Runnable action) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(dp(15), dp(12), dp(15), dp(12));
        box.setFocusable(true);
        box.setClickable(true);
        box.setBackgroundResource(br.com.philcostream.R.drawable.card_background);
        LinearLayout.LayoutParams outer = (LinearLayout.LayoutParams) null;
        TextView icon = text(symbol, 25, ACCENT, true);
        TextView t = text(title, 14, Color.WHITE, true);
        TextView d = text(desc, 12, MUTED, false);
        box.addView(icon);
        box.addView(t);
        LinearLayout.LayoutParams dp0 = new LinearLayout.LayoutParams(-1, -2);
        dp0.topMargin = dp(5);
        box.addView(d, dp0);
        box.setOnClickListener(v -> action.run());
        box.setOnKeyListener((v, key, event) -> {
            if (event.getAction() == KeyEvent.ACTION_UP &&
                (key == KeyEvent.KEYCODE_DPAD_CENTER || key == KeyEvent.KEYCODE_ENTER)) {
                action.run(); return true;
            }
            return false;
        });
        box.setFocusableInTouchMode(false);
        return box;
    }

    private void askAddon() {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setText("https://");
        input.setHint("https://endereco-do-addon/manifest.json");
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        new AlertDialog.Builder(this)
            .setTitle("Adicionar add-on")
            .setMessage("Cole a URL do manifesto (manifest.json). Use apenas add-ons em que você confia.")
            .setView(input)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Verificar", (d, w) -> fetchManifest(input.getText().toString().trim()))
            .show();
    }

    private void fetchManifest(String raw) {
        if (raw.length() == 0) return;
        String address = raw;
        if (!address.endsWith("manifest.json")) {
            if (!address.endsWith("/")) address += "/";
            address += "manifest.json";
        }
        final String target = address;
        status.setText("Verificando manifesto…");
        io.execute(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(target).openConnection();
                c.setConnectTimeout(10000);
                c.setReadTimeout(12000);
                c.setRequestProperty("User-Agent", "PhilcoStream/0.1");
                int code = c.getResponseCode();
                InputStream stream = (code >= 200 && code < 400) ? c.getInputStream() : c.getErrorStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
                StringBuilder out = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) out.append(line);
                br.close(); c.disconnect();
                JSONObject manifest = new JSONObject(out.toString());
                String name = manifest.optString("name", "Add-on sem nome");
                String id = manifest.optString("id", "");
                JSONArray resources = manifest.optJSONArray("resources");
                JSONArray catalogs = manifest.optJSONArray("catalogs");
                final String result = "Add-on reconhecido: " + name + "\nID: " + id +
                    "\nRecursos: " + (resources == null ? "não informado" : resources.toString()) +
                    "\nCatálogos: " + (catalogs == null ? "não informado" : catalogs.length()) +
                    "\n\nNesta versão inicial, o manifesto é validado; a listagem de títulos e reprodução serão implementadas na próxima etapa.";
                main.post(() -> {
                    status.setText("Manifesto verificado: " + name);
                    new AlertDialog.Builder(this).setTitle("Manifesto válido").setMessage(result)
                        .setPositiveButton("OK", null).show();
                });
            } catch (Exception e) {
                final String msg = e.getClass().getSimpleName() + ": " + (e.getMessage() == null ? "não foi possível ler o manifesto" : e.getMessage());
                main.post(() -> {
                    status.setText("Não foi possível verificar o add-on.");
                    new AlertDialog.Builder(this).setTitle("Falha ao verificar")
                        .setMessage(msg + "\n\nConfira a URL e a conexão. Alguns add-ons exigem HTTPS, cabeçalhos ou recursos ainda não implementados.")
                        .setPositiveButton("OK", null).show();
                });
            }
        });
    }

    private void askSearch() {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("Nome de filme ou série");
        new AlertDialog.Builder(this).setTitle("Buscar")
            .setView(input).setNegativeButton("Cancelar", null)
            .setPositiveButton("Buscar", (d, w) -> Toast.makeText(this,
                "A busca real entra na próxima etapa: " + input.getText().toString(), Toast.LENGTH_LONG).show())
            .show();
    }

    private void info() {
        new AlertDialog.Builder(this).setTitle("Sobre o projeto")
            .setMessage("Philco Stream 0.1.0\nJava + Android Views/XML\nMin SDK 19 (Android 4.4)\nSem Compose e sem WebView na interface.\n\nEsta é a base inicial, não um cliente Stremio completo ainda.")
            .setPositiveButton("OK", null).show();
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setFocusable(true);
        b.setBackgroundResource(br.com.philcostream.R.drawable.card_background);
        return b;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        io.shutdownNow();
    }
}
